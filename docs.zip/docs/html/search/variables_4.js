var searchData=
[
  ['playerboard_65',['playerBoard',['../structGame.html#aedc54a6c1c98a27495136f1774a1f11e',1,'Game']]],
  ['playerboats_66',['playerBoats',['../structGame.html#af65be8af7efa76c5e1fd1426cd17c987',1,'Game']]]
];

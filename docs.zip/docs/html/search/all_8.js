var searchData=
[
  ['num_5fboats_24',['NUM_BOATS',['../game_8c.html#af72794d64123d5561814c1a2618cd062',1,'NUM_BOATS():&#160;game.c'],['../game_8h.html#af72794d64123d5561814c1a2618cd062',1,'NUM_BOATS():&#160;game.c']]]
];

var searchData=
[
  ['canplaceboat_43',['canPlaceBoat',['../game_8c.html#a8f419cdd14adf56bb18a6c323892ba1f',1,'canPlaceBoat(struct GameBoard *board, struct Boat *boat):&#160;game.c'],['../game_8h.html#a8f419cdd14adf56bb18a6c323892ba1f',1,'canPlaceBoat(struct GameBoard *board, struct Boat *boat):&#160;game.c']]],
  ['checkvictory_44',['checkVictory',['../game_8c.html#a674e7f16c936b0ffa77367f8a9565d5e',1,'checkVictory(struct GameBoard *board):&#160;game.c'],['../game_8h.html#a674e7f16c936b0ffa77367f8a9565d5e',1,'checkVictory(struct GameBoard *board):&#160;game.c']]],
  ['computerturn_45',['computerTurn',['../game_8c.html#af2eb2b76212bb9fee83c07feccea8e05',1,'computerTurn(struct Game *game):&#160;game.c'],['../game_8h.html#af2eb2b76212bb9fee83c07feccea8e05',1,'computerTurn(struct Game *game):&#160;game.c']]],
  ['createboat_46',['createBoat',['../game_8c.html#a44fdfe285a52f71199477f530ab4929d',1,'createBoat(int size, int row, int col, bool horizontal):&#160;game.c'],['../game_8h.html#a44fdfe285a52f71199477f530ab4929d',1,'createBoat(int size, int row, int col, bool horizontal):&#160;game.c']]],
  ['creategameboard_47',['createGameBoard',['../game_8c.html#a009a259f4567cbea48659d08e9b93d67',1,'createGameBoard(int size):&#160;game.c'],['../game_8h.html#a009a259f4567cbea48659d08e9b93d67',1,'createGameBoard(int size):&#160;game.c']]]
];

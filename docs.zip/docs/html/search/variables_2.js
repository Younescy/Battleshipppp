var searchData=
[
  ['horizontal_63',['horizontal',['../structBoat.html#a5f9a5d7a77f4f117e78f8d617b5ab6ef',1,'Boat']]]
];
